
== notes for generating pot file 

The included Preset2Pot utility will generate a .pot file from a JOSM preset file.

